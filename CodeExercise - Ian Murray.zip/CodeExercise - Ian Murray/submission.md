# Submission Notes

These notes will be read by HubSpot developers. Drop us a line!

Ian Murray - Submission 23/03/2020
murraymurs@gmail.com

## Given more time, what would you have done differently?

Unfortunately I am working on a major version product release this week and was only able to devote a set amount of
time to this coding exercise at the weekend. I focused on a minimum viable product. I completed exercise 1 as described. For exercise 2
I broke it up into smaller pieces of work. I identified the components (filters, search, title) and implemented them
individually in React functional components. The logic is done in the index file. I did not have time to develop further
than what is submitted.

Given more time I would like to have written a service or store to manage/process the data, so that multiple filters could be
applied at the same time, and keep the filters in sync with one another. Redux may have been an option for this, but I am aware that it is being phased out. Hooks are another
option, but I have not worked on React in 2 years, so have limited exposure to hooks. Currently the filters are mutually exclusive.

The poster grid flows using flex, but I would like to have implemented a three column grid, and
used small, medium and large breakpoints for mobile, tablet and desktop.

## How did you deviate from the directions, if at all, and why?

I did not fully implement the select inputs as described. I would have liked to implement a custom multi-select component,
as the one I used was simply a styled native single select. This would have consisted of a container div, select div, flyout,
and a child select-option component with a checkbox and span.

## Is there anything else you'd like to let us know?

This is an excellent code exercise application. I've not see one so thoroughly developed. A couple small things would
be that "The Exorcist" poster url throws a 404, and the 'Clear Filters' link should be a button from an A11y standpoint,
as it performs an action and does not navigate. Dealers choice though. :)
