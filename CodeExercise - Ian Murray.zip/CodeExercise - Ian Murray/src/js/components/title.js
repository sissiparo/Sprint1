import React from "react";

export function Title(props) {
    return (<div className="title-container">
        <img className="title-container__image" src={props.titleInfo.poster}/>
        <span className="title-container__name">{props.titleInfo.title}</span>
        <span className="title-container__genres">Genre: {props.titleInfo.genre.join(', ')}</span>
    </div>);
}
