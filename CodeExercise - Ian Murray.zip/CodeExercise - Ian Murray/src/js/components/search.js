import React from "react";

export function Search({resetCallback, searchCallback}) {
    return (<div className="filter-search-container">
        <input id='search' onChange={e => searchCallback(e.target.value)} className='filter-search-container__input'/>
        <a href="#" onClick={resetCallback}>Clear Filters</a>
    </div>);
}
