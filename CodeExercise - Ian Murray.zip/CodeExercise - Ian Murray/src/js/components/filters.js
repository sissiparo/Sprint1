import React from "react";

export function Filters({genres, years, genreSelectCallback, yearSelectCallback, radioSelectCallback}) {
    return (<div className='filters'>
        <div className='filters__select-container'>
            <select id="genre-select" className='filters-select-container__genre' onChange={genreSelectCallback}>
                <option hidden>Genre</option>
                {genres && genres.map((genre, i) => <option key={i}>
                    {genre}
                </option>)}
            </select>
            <select id="year-select" className='filters-select-container__year' onChange={yearSelectCallback}>
                <option hidden>Year</option>
                {years && years.map((year, i) => <option key={i}>
                    {year}
                </option>)}
            </select>
        </div>
        <div className='filters__radio-container'>
            <input onClick={radioSelectCallback} type="radio" id="movie" name="movie" value="movie"/>
            <label className='filters-radio-container__movie-label' htmlFor="movies">Movies</label>
            <input onClick={radioSelectCallback} type="radio" id="book" name="book" value="book"/>
            <label className='filters-radio-container__bool-label' htmlFor="books">Books</label>
        </div>
    </div>);
}
