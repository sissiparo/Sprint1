import '../styles/index.less';
import React from "react";
import ReactDOM from "react-dom";
import {getGenres, getYears} from './utilities/process-medie.utility';
import {Filters} from "./components/filters";
import {Search} from "./components/search";
import {Title} from "./components/title";

const e = React.createElement;

const resetFunctions = {
    'genre': resetGenre,
    'year': resetYear,
    'movie': resetMovie,
    'book': resetBook,
    'search': resetSearch,
};


class Index extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            media: null,
            genres: null,
            years: null,
            filteredMedia: null
        };
    }

    componentDidMount() {
        fetch("https://hubspotwebteam.github.io/CodeExercise/src/js/data/data.json")
            .then(res => res.json())
            .then(
                (result) => {
                    const media = result.media.sort((a, b) => (a.title > b.title) ? 1 : ((b.title > a.title) ? -1 : 0));
                    this.setState({
                        media: media,
                        filteredMedia: media,
                        genres: getGenres(media),
                        years: getYears(media)
                    });
                },
            )
    }

    render() {
        return <div className="filterable-content">
            <div className="filterable-content__header">
                <Filters
                    genres={this.state.genres}
                    years={this.state.years}
                    genreSelectCallback={this.genreSelectCallback.bind(this)}
                    yearSelectCallback={this.yearSelectCallback.bind(this)}
                    radioSelectCallback={this.radioSelectCallback.bind(this)}
                />
                <Search resetCallback={this.resetCallback.bind(this)} searchCallback={this.searchCallback.bind(this)}/>
            </div>
            <div className="media-container">
                {this.state.filteredMedia && this.state.filteredMedia.map((x, i) => <Title key={i} titleInfo={x}/>)}
            </div>
        </div>;
    }

    /**
     * Resets other filters and filters media based on genre
     * @param event
     */
    genreSelectCallback(event) {
        resetOtherFilters('genre');
        const selectedGenre = event.target.value;
        const filteredMedia = this.state.media.filter((media) => {
            return media.genre.indexOf(selectedGenre) > -1;
        });
        this.setState({
            filteredMedia: filteredMedia,
        });
    }

    /**
     * Resets other filters and filters media based on year
     * @param event
     */
    yearSelectCallback(event) {
        resetOtherFilters('year');
        const selectedYear = event.target.value;
        const filteredMedia = this.state.media.filter((media) => {
            return media.year === selectedYear;
        });
        this.setState({
            filteredMedia: filteredMedia,
        });
    }

    /**
     * Resets all filters and set media to default
     */
    resetCallback() {
        resetOtherFilters();
        this.setState({
            filteredMedia: this.state.media,
        });
    }

    /**
     * Resets other filters and filters media based on radio type (movie, book)
     * @param event
     */
    radioSelectCallback(event) {
        const type = event.target.value;
        resetOtherFilters(type);
        const filteredMedia = this.state.media.filter((media) => {
            return media.type === type;
        });
        this.setState({
            filteredMedia: filteredMedia,
        });
    }

    /**
     * Resets other filters and filters media based search input, with 500ms debounce
     * @param value
     */
    searchCallback(value) {
        resetOtherFilters('search');
        const filteredMedia = this.state.media.filter((media) => {
            return media.title.toLowerCase().indexOf(value.toLowerCase()) > -1;
        });
        this.setState({
            filteredMedia: filteredMedia,
        });
    }
}

function resetGenre() {
    const genreSelect = document.getElementById("genre-select");
    genreSelect.selectedIndex = 0;
}

function resetYear() {
    const genreSelect = document.getElementById("year-select");
    genreSelect.selectedIndex = 0;
}

function resetMovie() {
    const movieRadio = document.getElementById("movie");
    movieRadio.checked = false;
}

function resetBook() {
    const bookRadio = document.getElementById("book");
    bookRadio.checked = false;
}

function resetSearch() {
    const search = document.getElementById("search");
    search.value = '';
}

function resetOtherFilters(filterType) {
    Object.entries(resetFunctions).forEach(([key, value]) => {
        key !== filterType && value();
    });
}

const domContainer = document.querySelector('#filterable-content_container');
ReactDOM.render(e(Index), domContainer);
