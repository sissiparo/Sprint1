export function getGenres(media) {
    let allGenres = [];

    media.forEach(title => {
        allGenres = [...allGenres, ...title.genre]
    });
    return uniqueArray(allGenres).sort();
}

export function getYears(media) {
    let allYears = [];

    media.forEach(title => {
        allYears.push(title.year);
    });

    return uniqueArray(allYears).sort();
}

function uniqueArray(nonUniqueArray) {
    return nonUniqueArray.reduce((newArray, item) =>{
        if (newArray.includes(item)){
            return newArray
        } else {
            return [...newArray, item]
        }
    }, []);
}
